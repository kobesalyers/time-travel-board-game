clear
clc

% this function gives a list of webcams.
camList = webcamlist;

cam = webcam(2); % extrernal webcam was ___ on the list.

preview(cam); % this turns on the video.

for countDown = 10: 1:1
    disp(countDown);
end

pause(2);

image = snapshot(cam); % takes a snapshot.

imshow(image); % Show the image.