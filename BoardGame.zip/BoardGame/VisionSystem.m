
%{ Authors:    Kobe Salyers
%  Assignment: EGR 103 - Board Game Vision System
%  Changed:    March 9, 2025
%  History:    March 8, 2025 - Initial Creation
%  Purpose:    To create code for the board game's vision system 
%              for EGR 103.
%}


% this function gives a list of webcams.
camList = webcamlist;

cam = webcam(2); % extrernal webcam was ___ on the list.

preview(cam); % this turns on the video.

for countDown = 10: 1:1
    disp(countDown);
end

pause(2);

image = snapshot(cam); % takes a snapshot.

% Show the image
imshow(image)

% Hard-Coded coordinates
Cropping_Permanent = [234   191   146    87];

% Tell MATLAB where to crop the image using the cropping coordinates you
% found
croppedImage = imcrop(image, Cropping_Permanent);

% Show cropped image
imshow(croppedImage)

% Inspect cropped image
imtool(croppedImage);

%get the values for each channel separated out:
g_channel=croppedImage(:,:,2);
r_channel=croppedImage(:,:,1);
b_channel=croppedImage(:,:,3);

% create variables for the ratios
rg_ratio=double(r_channel)./double(g_channel); % red green ratio
gb_ratio=double(g_channel)./double(b_channel); % green blue ratio
rg_ratio(isnan(rg_ratio))=0; % if it is nan it sets it to zero
gb_ratio(isnan(gb_ratio))=0; % this should only happen if it is black

% Sets the cooresponding r/g ratio to the dots on dice
Dots = (r_channel <= 65) | (gb_ratio == 0);

% Show image in black & white with dots
imshow(Dots);

% Removes dots eith less than 100 pixels
ImprovedPic = bwareaopen(Dots,100); 

% Shows this improved image
imshow(ImprovedPic)

% Fill in holes
filledHoles = imfill(Dots,'holes');
Improved2 = bwareaopen(filledHoles,100);
imshow(Improved2)

% Counts number of white dots & stores in table. Amount of rows 
% is amount of dots
tableOfProp = regionprops('table',Improved2, 'BoundingBox');

% Assigns found number of dots to "NumberRolled" variable
NumberRolled = height(tableOfProp); 

