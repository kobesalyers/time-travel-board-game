clc
clear

a = arduino('COM5', 'Uno','Libraries', 'Servo');

s = servo(a, 'D5', 'MinPulseDuration', 500e-6, 'MaxPulseDuration', 2500e-6);

writePosition(s,0.305);
pause(2);
writePosition(s,1);
pause(2);
writePosition(s,0.305);
pause(2);

s1 = servo(a, 'D6', 'MinPulseDuration', 500e-6, 'MaxPulseDuration', 2500e-6);

writePosition(s1,0.5);
pause(2);
writePosition(s1,0);
pause(2);
writePosition(s1,0.5);

