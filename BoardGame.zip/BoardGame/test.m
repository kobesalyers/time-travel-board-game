
% this function gives a list of webcams.
camList = webcamlist;

cam = webcam(2); % extrernal webcam was ___ on the list.

preview(cam); % this turns on the video.

for countDown = 10: 1:1
    disp(countDown);
end

pause(2);

image = snapshot(cam); % takes a snapshot.

% Show the image
imshow(image)

%% Step 2: Example of How to Crop an Image (Not Necessary for Assignment, but good
% Show the image you want to crop
imshow(image)

Cropping = round(getPosition(imrect));

% Display the coordinates of your cropping rectangle
disp(Cropping)
